#!/bin/sh

while :
do
	now=$(date +"%m-%d-%y")
	echo "====Date : $now ===" >> ./mem_track.txt
	cat /proc/meminfo >> ./mem_track.txt
	/bin/sleep $1
done
