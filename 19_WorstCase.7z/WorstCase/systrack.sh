#!/bin/sh

echo "=============================================" 
	now=$(date +"%m-%d-%y")
	echo "====Date : $now ===" 
	TotalMem=$(cat /proc/meminfo | awk 'NR==1{printf "%d\n",$2}')
	MinAvalMem=$(cat /proc/meminfo | awk 'NR==3{printf "%d\n", $2}')
	
	MaxTotalCPU=$(top -bn1 | grep 'CPU:\|top')
	MaxTotalCPU1=$(echo "$MaxTotalCPU" | awk 'NR==1{printf "%d\n",100-$8}')
	MaxTotalCPU2=$(echo "$MaxTotalCPU" | awk 'NR==2{printf "%d\n",$8}')
	MaxCPU=$(($MaxTotalCPU1-$MaxTotalCPU2))
	PreCPU=$MaxCPU
	AveCPU=$MaxCPU
while :
do
	
	now=$(date +"%m-%d-%y-%T") 
	echo "====Time : $now ===="
	
	CurAvailMem=$(cat /proc/meminfo | awk 'NR==3{printf "%d\n", $2}')
	
	if [ "$CurAvailMem" -le "$MinAvalMem" ]; then
		MinAvalMem=$CurAvailMem
	fi
	
	echo "TotalMem = "$TotalMem" MB"
	echo "CurUsedMem = "$(($TotalMem-$CurAvailMem)) "MB" $(( ($TotalMem-$CurAvailMem)*100/$TotalMem )) "%"
	echo "MaxusedMem = "$(($TotalMem-$MinAvalMem)) "MB" $(( ($TotalMem-$MinAvalMem)*100/$TotalMem )) "%"
	
	TotalCPU=$(top -bn1 | grep 'CPU:\|top')
	TotalCPU1=$(echo "$TotalCPU" | awk 'NR==1{printf "%d\n",100-$8}')
	TotalCPU2=$(echo "$TotalCPU" | awk 'NR==2{printf "%d\n",$8}')
	
	if [ "$TotalCPU1" -ge "$TotalCPU2" ]; then
		CurCPU=$(($TotalCPU1-$TotalCPU2))
	else
		CurCPU=$TotalCPU1
	fi
	
	if [ "$CurCPU" -ge 80 ]; then
		top -bn1
	fi
	
	if [ "$MaxCPU" -le "$CurCPU" ]; then
		MaxCPU=$CurCPU
	fi
	
	AveCPU=$(( ($CurCPU+$AveCPU)/2 ))
	PreCPU=$CurCPU
	echo "Cur CPU Usage:"$CurCPU
	echo "Max CPU Usage:"$MaxCPU
	echo "Ave CPU Usage:"$AveCPU					
	##grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage "%"}'
	
	
		
	/bin/sleep $1
done
