#!/bin/sh

##echo "Dumping data"
##date
##echo "Date:" >> /data/memory_logs.txt
##date >> /data/memory_logs.txt
##echo "Memory Info:" >> /data/memory_logs.txt

while :
do
now=$(date +"%m-%d-%y")
echo "====Date : $now ===" 
		
for i in `busybox ps | grep "." | grep -v grep | awk '{print $1}'`; do
	if [ ! -d /proc/$i ]; then
		continue
	fi

	name=$(awk '{print $2}' /proc/$i/stat)

	pss=$(awk '/Pss:/{ sum += $2 } END { printf "%.0f", sum }' /proc/$i/smaps)
	rss=$(awk '/Rss:/{ sum += $2 } END { printf "%.0f", sum }' /proc/$i/smaps)
	uss=$(awk '/Private_Clean:/{ sum += $2 } /Private_Dirty:/{ sum += $2 } END { printf "%.0f", sum }' /proc/$i/smaps)

	cat /proc/$i/smaps | grep -A 15 heap > /data/heap.txt
	cat /proc/$i/smaps | grep -A 15 stack > /data/stack.txt
	cat /proc/$i/smaps | grep -A 15 anon > /data/anon.txt

	pss_heap=$(awk '/Pss:/{ sum += $2 } END { printf "%.0f", sum }' /data/heap.txt)
	pss_stack=$(awk '/Pss:/{ sum += $2 } END { printf "%.0f", sum }' /data/stack.txt)
	pss_anon=$(awk '/Pss:/{ sum += $2 } END { printf "%.0f", sum }' /data/anon.txt)

	if [ -n "$pss" ]; then
		printf "PID %-d %-s :\tPSS : %-d\tRSS : %d\tUSS : %d\tPSS_HEAP : %-d\tPSS_STACK : %-d\tPSS_ANON : %-d\n" $i "$name" $pss $rss $uss $pss_heap $pss_stack $pss_anon
		##echo "PID NAME  PSS	 RSS  USS  PSS_HEAP  PSS_STACK  PSS_ANON" >> /data/memory_logs.txt
		##echo $i "$name" $pss $rss $uss $pss_heap $pss_stack $pss_anon >> /data/memory_logs.txt
	fi
done

#current_time=$(date "+%Y.%m.%d-%H.%M.%S")
#cat /proc/meminfo >> /data/memory/proc_meminfo_$current_time.txt
#cat /proc/meminfo
#busybox free -m >> /data/memory/free_$current_time.txt
#cat /proc/buddyinfo >> /data/memory/proc_buddyinfo_$current_time.txt

echo "====/proc/meminfo ===" 
cat /proc/meminfo
echo "====busybox free -m ==="
busybox free -m
echo "====/proc/buddyinfo ==="
cat /proc/buddyinfo

	/bin/sleep $1
done
